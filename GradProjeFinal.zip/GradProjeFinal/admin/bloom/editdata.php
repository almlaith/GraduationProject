<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->

  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->
  <title>Add bloom</title>
</head>
<?php require "db_conn.php"; 
$id= (int)$_GET['id'];
   $ttable = mysqli_query($conn, 'SELECT * FROM bloom WHERE id=' . $id);


   while ($row = mysqli_fetch_array($ttable)) { ?>

<body>
  <div class="container">
    <form class="form-horizontal" role="form" method="post" action="edit.php">
      <h2>Add User</h2>
      <div class="form-group">
        <label for="fistName" class="col-sm-3 control-label">BLOOM NAME</label>
        <div class="col-sm-9">
          <input type="text" id="firstName" name="bloomname" placeholder="First Name" class="form-control" autofocus value="<?php echo $row['bloomname']
          ?>">
        </div>
      </div>

      <div class="form-group">
        <label for="password" class="col-sm-3 control-label">Category Name</label>
        <div class="col-sm-9">
        <select name="catid" id="catid">
                        <?php     require "db_conn.php";

                          $ttable2 = mysqli_query($conn, 'SELECT * FROM maincat ');

                           while ($row2 = mysqli_fetch_array($ttable2)) { ?>
                            <option value="<?php echo $row2['id']; ?>"><?php echo $row2['name']; ?></option>
                            <?php } ?>
                    </select>  
                    <input type="hidden" id="id" name="id" placeholder="First Name" class="form-control" autofocus value="<?php echo $id ?>" >
        </div>
      </div>




      <a><button type="submit" class="btn btn-primary btn-block">Edit</button>
    </form> <!-- /form -->
  </div> <!-- ./container -->
<?php }?>

</body>

</html>