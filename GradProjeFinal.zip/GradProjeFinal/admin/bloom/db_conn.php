<?php
$sarvername="localhost";
$uasername="root";
$pass="";
$db="final";

$conn=new mysqli($sarvername,$uasername,$pass,$db);

?>