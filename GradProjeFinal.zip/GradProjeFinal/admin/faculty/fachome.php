<!DOCTYPE html>
<html lang="en">

<head>
    <title>Faculty  HOME</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand mx-3" href="http://localhost/final/admin/home.php">Control User </a>
  </nav>


  <a type="button" href="facadd.php"><button type="button" class="btn btn-secondary btn-lg" href="bloomadd.php">Add Faculty</button></a>
  <hr />
  <div class="container">
  <h2>Hi ADMIN</h2>
  <p> the Faculty in data base</p>
  <table class="table">
    <thead> 
    <tr>
    <th>id</th>
    <th>faculty name</th>
    
    </tr>
  </thead>
 <tbody>
   <?php
   $sarvername="localhost";
   $uasername="root";
   $pass="";
   $db="final";
   
   $conn=new mysqli($sarvername,$uasername,$pass,$db);
  
   $ttable=mysqli_query($conn,'SELECT * FROM faculty');
 
   while ($row= mysqli_fetch_array($ttable)){ ?>
    <tr id="<?php echo $row['id'];?>">
    <td data-target="id" ><?php echo $row['id']; ?></td>
    <td data-target="facname" ><?php echo $row['facname']; ?></td>
    <td><a href="http://localhost/final/admin/faculty/editdata.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a></td>
    <td><a href="http://localhost/final/admin/faculty/delete-data.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">delete</button></a></td>
  </tr>
   <?php }?>
  
 </tbody>   
</table>

  </div>
  <hr />
  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" method="POST">
            <h2>update faculty</h2>                          
                <div class="form-group">
                <label for="fistName" class="col-sm-3 control-label">facname</label>
              <div class="col-sm-9">
              <input type="text" id="facname" name="facname" placeholder="First Name" class="form-control" autofocus>
              </div>
            </div>
           <div class="form-group">
              <label for="AdminID" class="col-sm-3 control-label">AdminID</label>
              <div class="col-sm-9">
                <input type="text" id="adminid" name="adminid" placeholder="Adminid" class="form-control">
              </div>
           
            <input type="text" id="userId" name="id" placeholder="department" class="form-control">




          </form> <!-- /form -->
        </div>
        <div class="modal-footer">
          <a href="#" id="save" class="btn btn-primary pull-right">Update</a>
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>
 
    
  <script>
$(document).ready(function() {
  //append values in input fields
$(document).on('click', 'a[data-role=update]',function(){
  var id=$(this).data('id');
  var facname=$('#'+id).children('td[data-target=facname]').text();
  var adminid=$('#'+id).children('td[data-target=adminid]').text();
  $('#facname').val(facname);
   $('#adminid').val(adminid);
  $('#userId').val(id);
  $('#myModal').modal('toggle');
});
//new create event to get data from fileds and update in database 
$('#save').click(function(){
  var id =$('#userId').val();
  var facname= $('#facname').val();
   var adminid=$('#adminid').val();
  
  $.ajax({
    url:'db_conn.php',
    method:'post',
    data:{facname:facname,adminid:adminid,id:id},
    success: function(response){
      alert(response)
    }

  });
});
//================================================================
//================================================================
$(document).on('click', 'a[data-role=delete]', function(){
  	var id = $(this).data('id');
  	$clicked_btn = $(this);
  	$.ajax({
  	  url: 'delete-data.php',
  	  type: 'GET',
  	  data: {
    	'delete': 1,
    	'id': id,
      },
      success: function(response){
        // remove the deleted comment
       
        $('#facname').val(facname);
  $('#adminid').val(adminid);
   $('#userId').val(id);
      }
  	});


});
});
</script>

</body>

</html>