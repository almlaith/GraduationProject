<?PHP
require "db_conn.php";
$facname=$_POST["facname"];
$id=$_POST["id"];

$sql = "UPDATE faculty SET facname='$facname' WHERE  id=" . $id;


if ($conn->multi_query($sql) == TRUE) {
    echo "DATA Insert";
    header('Location:http://localhost/final/admin/faculty/fachome.php');
}
else{
 echo "DATA NOT Insert";}
 $conn->close();








?>