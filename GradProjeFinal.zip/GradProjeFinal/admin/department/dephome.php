<!DOCTYPE html>
<html lang="en">

<head>
    <title>Department  HOME</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand mx-3" href="http://localhost/final/admin/home.php">Control User </a>
  </nav>


  <a type="button" href="depadd.php"><button type="button" class="btn btn-secondary btn-lg" href="bloomadd.php">Add Department</button></a>
  <hr />
  <div class="container">
  <h2>Hi ADMIN</h2>
  <p> the Department in data base</p>
  <table class="table">
    <thead> 
    <tr>
    <th>id</th>
    <th>Department Name</th>
    
    <th>faculty NAME </th>
    
    </tr>
  </thead>
 <tbody>
   <?php
   $sarvername="localhost";
   $uasername="root";
   $pass="";
   $db="final";
   
   $conn=new mysqli($sarvername,$uasername,$pass,$db);
  
   $ttable=mysqli_query($conn,'SELECT * FROM department');
 
   while ($row= mysqli_fetch_array($ttable)){ ?>
    <tr id="<?php echo $row['id'];?>">
    <td data-target="id" ><?php echo $row['id']; ?></td>
    <td data-target="DepName" ><?php echo $row['DepName']?> </td>
    <td data-target="facid" ><?php 
    require "db_conn.php";
    
    
     $ttable1=mysqli_query($conn,'SELECT * FROM faculty WHERE id='.$row['facid']);
   
     while ($row1= mysqli_fetch_array($ttable1)){
     echo $row1['facname'];
     } ?></td> 
 
 <td><a href="http://localhost/final/admin/department/editdata.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a></td>
    <td><a href="http://localhost/final/admin/department/delete-data.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">delete</button></a></td>
  </tr>
   <?php }?>
  
 </tbody>   
</table>

  </div>
  <hr />
  

    </div>
  </div>
 
    
  

</body>

</html>