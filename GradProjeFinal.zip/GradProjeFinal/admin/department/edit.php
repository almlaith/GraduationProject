<?PHP
require "db_conn.php";
$DepName=$_POST["DepName"];
$facid=$_POST["facid"];
$id=$_POST["id"];
$sql = "UPDATE department SET DepName='$DepName',facid='$facid' WHERE  id=" . $id;


if ($conn->multi_query($sql) == TRUE) {
    echo "DATA Insert";
    header('Location:http://localhost/final/admin/department/dephome.php');
}
else{
 echo "DATA NOT Insert";}
 $conn->close();








?>