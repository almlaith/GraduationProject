<?php
$DepName=$_POST["DepName"];
$facid=$_POST["facid"];
$sarvername = "localhost";
$uasername = "root";
$pass = "";
$db = "final";

$conn = mysqli_connect($sarvername, $uasername, $pass, $db);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql =   "INSERT INTO department( DepName,facid ) VALUES ('$DepName',$facid)";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
  header('Location:http://localhost/final/admin/department/dephome.php');
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>