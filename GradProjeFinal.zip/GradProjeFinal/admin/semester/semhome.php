<!DOCTYPE html>
<html lang="en">

<head>
    <title>BLOOM HOME</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand mx-3" href="http://localhost/final/admin/home.php">ADMIN HOME </a>
  </nav>


  <a type="button" href="semadd.php"><button type="button" class="btn btn-secondary btn-lg" href="bloomadd.php">Add Semester</button></a>
  <hr />
  <div class="container">
  <h2>Hi ADMIN</h2>
  <p> the Semester in data base</p>
  <table class="table">
    <thead> 
    <tr>
    <th>id</th>
    <th>semname</th>
    <th>admin </th>
    </tr>
  </thead>
 <tbody>
   <?php
   $sarvername="localhost";
   $uasername="root";
   $pass="";
   $db="final";
   
   $conn=new mysqli($sarvername,$uasername,$pass,$db);
  
   $ttable=mysqli_query($conn,'SELECT * FROM semester');
 
   while ($row= mysqli_fetch_array($ttable)){ ?>
    <tr id="<?php echo $row['id'];?>">
    <td data-target="id" ><?php echo $row['id']; ?></td>
    <td data-target="semname" ><?php echo $row['semname']; ?></td>
   
    <td><a href="http://localhost/final/admin/semester/editdata.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a></td>
    <td><a href="http://localhost/final/admin/semester/delete-data.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">delete</button></a></td>
  </tr>
   <?php }?>
  
 </tbody>   
</table>

  </div>
  <hr />
  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" method="POST">
            <h2>update semester</h2>                          
                <div class="form-group">
                <label for="fistName" class="col-sm-3 control-label">semname</label>
              <div class="col-sm-9">
              <input type="text" id="semname" name="semname" placeholder="First Name" class="form-control" autofocus>
              </div>
            </div>
           <div class="form-group">
              <label for="AdminID" class="col-sm-3 control-label">AdminID</label>
              <div class="col-sm-9">
                <input type="text" id="adminid" name="adminid" placeholder="Adminid" class="form-control">
              </div>
           
            <input type="text" id="userId" name="id" placeholder="department" class="form-control">




          </form> <!-- /form -->
        </div>
       
        </div>
        </div>
    


</body>

</html>