<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <title>Add bloom</title>
</head>

<body>
<div class="container">
        <form class="form-horizontal"  role="form" method="post" action="add.php" >
            <h2>Add User</h2>
            <div class="form-group">
                <label for="fistName" class="col-sm-3 control-label">semester NAME</label>
                <div class="col-sm-9">
                    <input type="text" id="firstName" name="semname" placeholder="First Name" class="form-control" autofocus>
                </div>
            </div>
               
          
          
            
            

            <a href="#"><button type="submit" class="btn btn-primary btn-block">ADD</button></a>
                   </form> <!-- /form -->
    </div> <!-- ./container --> 


</body>
