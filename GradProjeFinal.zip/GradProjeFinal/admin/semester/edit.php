<?PHP
require "db_conn.php";
$semname=$_POST["semname"];
$id=$_POST["id"];

$sql = "UPDATE semester SET semname='$semname' WHERE  id=" . $id;


if ($conn->multi_query($sql) == TRUE) {
    echo "DATA Insert";
    header('Location:http://localhost/final/admin/semester/semhome.php');
}
else{
 echo "DATA NOT Insert";}
 $conn->close();








?>