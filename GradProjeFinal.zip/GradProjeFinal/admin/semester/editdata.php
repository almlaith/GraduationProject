<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <title>Add bloom</title>
</head>

<body>
<?php
   $sarvername="localhost";
   $uasername="root";
   $pass="";
   $db="final";
   
   $conn=new mysqli($sarvername,$uasername,$pass,$db);
   $id= (int)$_GET['id'];
   $ttable=mysqli_query($conn,'SELECT * FROM semester WHERE id='.$id);
 
   while ($row= mysqli_fetch_array($ttable)){ ?>
<div class="container">
        <form class="form-horizontal"  role="form" method="post" action="edit.php" >
            <h2>Add User</h2>
            <div class="form-group">
                <label for="fistName" class="col-sm-3 control-label">semester NAME</label>
                <div class="col-sm-9">
                    <input type="text" id="firstName" name="semname" placeholder="First Name" value="<?php echo $row['semname']?>" class="form-control" autofocus>
                </div>
            </div>
            <input type="hidden" id="firstName" name="id" placeholder="First Name" value="<?php echo $row['id']?>" class="form-control" autofocus>

          
          <?php }?>
            
            

            <a href="#"><button type="submit" class="btn btn-primary btn-block">EDIT</button></a>
                   </form> <!-- /form -->
    </div> <!-- ./container --> 


</body>
