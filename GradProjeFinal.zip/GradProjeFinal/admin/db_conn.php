<?php
$sarvername="localhost";
$uasername="root";
$pass="";
$db="final";

$conn=new mysqli($sarvername,$uasername,$pass,$db);
if($conn->connect_error)
{
    die("not connect :".$conn->connect_error);
    }
    else
    {
        echo "ALL Good <Connected";
    }


?>