<?PHP
require "db_conn.php";
$username=$_POST["username"];
$userid=$_POST["userid"];
$email=$_POST["email"];
$pass=$_POST["pass"];
$roleid=$_POST["role"];
$department=$_POST["department"];
$sql = "UPDATE user SET username='$username',email='$email',pass='$pass',roleid='$roleid',depid='$department' WHERE  id=" . $userid;


if ($conn->multi_query($sql) == TRUE) {
    echo "DATA Insert";
    header('Location:http://localhost/final/admin/user/userhome.php');
}
else{
 echo "DATA NOT Insert";}
 $conn->close();








?>