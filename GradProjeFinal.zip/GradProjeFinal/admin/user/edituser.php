<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <title>Add User</title>
</head>

<body>
    <?php
    require "db_conn.php";
    $id = (int)$_GET['id'];
    $ttable = mysqli_query($conn, 'SELECT * FROM user WHERE id=' . $id);


    while ($row = mysqli_fetch_array($ttable)) { ?>



        <div class="container">
            <form class="form-horizontal" action="edit.php" role="form" method="POST">
                <h2>Add User</h2>
                <div class="form-group">
                    <label for="fistName" class="col-sm-3 control-label">username</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" name="username" placeholder="First Name" class="form-control" autofocus value="<?php echo $row['username']; ?>">
                    </div>
                </div>


                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email* </label>
                    <div class="col-sm-9">
                        <input type="text" id="email" class="form-control" name="email" value="<?php echo $row['email']; ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">Roleid</label>




                    <select name="role" id="role">
                        <?php $ttable1 = mysqli_query($conn, 'SELECT * FROM role');

                           while ($row1 = mysqli_fetch_array($ttable1)) { ?>
                            <option value="<?php echo $row1['roleid']; ?>"><?php echo $row1['name']; ?></option>
                            <?php } ?>
                    </select>
               


                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label">pass</label>
                    <div class="col-sm-9">
                        <input type="text" id="pass" name="pass" placeholder="pass" class="form-control" value="<?php echo $row['pass']; ?>">
                    </div>
                </div>
                <div class="form-group">
                
                    <label for="password" class="col-sm-3 control-label">department</label>
                    <div class="col-sm-9">
                    <select name="department" id="department">
                        <?php  $ttable2 = mysqli_query($conn, 'SELECT * FROM department ');

                           while ($row2 = mysqli_fetch_array($ttable2)) { ?>
                            <option value="<?php echo $row2['id']; ?>"><?php echo $row2['DepName']; ?></option>
                            <?php } ?>
                    </select>                        <input type="hidden" id="firstName" name="userid" placeholder="First Name" value="<?php echo $id; ?>"class="form-control" autofocus>

                    </div>
                </div>

                <?php } ?>

                <button type="submit" class="btn btn-primary btn-block">EDIT</button>
            </form> <!-- /form -->
        
        </div> <!-- ./container -->
</body>

</html>