<?php
require "db_conn.php";
$name=$_POST["username"];
$email=$_POST["email"];
$pass=$_POST["pass"];

$roleid=$_POST["roleid"];
$department=$_POST["department"];


if ($conn->connect_error) {
    die("not connect :" . $conn->connect_error);
} else {
    echo "ALL Good <Connected";
   
    $sqi = "INSERT INTO user ( username, email, pass, roleid, depid)VALUES('$name','$email','$pass','$roleid','$department')";
    if ($conn->multi_query($sqi) == TRUE) {
        echo "DATA Insert";
       header('Location:http://localhost/final/admin/user/userhome.php');
    } 
    $conn->close();
    
}



?>