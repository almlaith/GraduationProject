<!DOCTYPE html>
<html lang="en">

<head>
    <title>USER HOME</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand mx-3" href="http://localhost/final/admin/home.php">Control User </a>
  </nav>


  <a type="button" href="useradd.php"><button type="button" class="btn btn-secondary btn-lg" href="useradd.php">Add User</button></a>
  <hr />
  <div class="container">
  <h2>hi ADMIN</h2>
  <p> the user in data base</p>
  <table class="table">
    <thead> 
    <tr>
    <th>id</th>
    <th>username</th>
    <th>email</th>
    <th>pass</th>
    <th>ROLE</th>
    <th>depid</th>
    <th>#</th>
    <th>#</th>
  </tr>
  </thead>
 <tbody>
   <?php
   $sarvername="localhost";
   $uasername="root";
   $pass="";
   $db="final";
   
   $conn=new mysqli($sarvername,$uasername,$pass,$db);
   $ttable=mysqli_query($conn,'SELECT * FROM user');
 
 
   while ($row= mysqli_fetch_array($ttable)){ ?>
    <tr id="<?php echo $row['id'];?>">
    <td data-target="id" ><?php echo $row['id']; ?></td>
    <td data-target="username" ><?php echo $row['username']; ?></td>
    <td data-target="email" ><?php echo $row['email']; ?></td>
    <td data-target="pass" ><?php echo $row['pass']; ?></td>
    <td data-target="pass" >
      <?php $ttable1 = mysqli_query($conn, 'SELECT * FROM role WHERE roleid= '.$row['roleid']);
 
    $row1 = mysqli_fetch_array($ttable1);
    echo $row1['name'];
     ?>
     </td>
   <td data-target="depid" ><?php  
    $ttable2 = mysqli_query($conn, 'SELECT * FROM department WHERE id= '.$row['depid']);
 
    $row2 = mysqli_fetch_array($ttable2);
    echo $row2['DepName']
   ?></td>

    <td><a href="http://localhost/final/admin/user/edituser.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a></td>
    <td><a href="http://localhost/final/admin/user/delete.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">delete</button></a></td>

   
  </tr>
   <?php }?>
  
 </tbody>   
</table>

  </div>
  <hr />
  




</body>

</html>