<?php
$sarvername="localhost";
$uasername="root";
$pass="";
$db="final";

$conn=new mysqli($sarvername,$uasername,$pass,$db);

if (!$conn) {
    die('Connection failed ' . mysqli_error($conn));
  }
  
  // delete comment fromd database
  if (isset($_GET['delete'])) {
  	$id = $_GET['id'];
  	$sql = "DELETE FROM user WHERE id=" . $id;
  	mysqli_query($conn, $sql);
  	exit();
  }
  
  
?>