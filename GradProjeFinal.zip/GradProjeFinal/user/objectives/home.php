<?php include "nav.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
<table class="table">
  <thead class="thead-light">

    <tr>
      <th scope="col" colspan="4"> <center>Course OBJECTIVES</center></th>
     
    </tr>
    
  </thead>
  <tbody>
  <?php
  $id= (int)$_GET['id'];
          require "db_conn.php";
          $ttable = mysqli_query($conn, 'SELECT * FROM objectives WHERE courseid='.$id);


          while ($row = mysqli_fetch_array($ttable)) { ?>
    <tr >
    <tr colspan="4" >
     
      <td colspan="4"><center><?php echo $row['obj'] ?>  <center></td>
      
    </tr>
    <?php } ?>
  </tbody>
</table>

<center><a <a href="http://localhost/final/user/objectives/editobj.php?id=<?php echo $row['id'] ?>">><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a></center>
<?php
 if(isset($row['obj']))
 {
   ?>
   <center><a href=""><button type="button" class="btn btn-primary btn-lg btn-block">ADD</button></a></center>
   <?php
 }
?>

</body>
</html>