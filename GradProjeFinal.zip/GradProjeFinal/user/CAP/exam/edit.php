<?php
require "db_conn.php";
$id = $_POST['id'];
$grade = $_POST['grade'];
$exam = $_POST['exam'];
$s=0;
$ttable1 = mysqli_query($conn, 'SELECT idcourse ,grade FROM exam WHERE  id=' . $id);
$row1 = mysqli_fetch_array($ttable1);
$C=$row1['idcourse'];
$g=$row1['grade'];

$ttable = mysqli_query($conn, 'SELECT grade FROM exam WHERE  idcourse='. $C);
while ($row = mysqli_fetch_array($ttable)) {
    $s = $s + $row['grade'];
   
}
$s-=$g;
$s += $grade;
if($grade<=100&& $grade>0 && $s<=100)
{
$sql = "UPDATE exam SET nameexam='$exam' , grade='$grade'    WHERE id=" . $id;
mysqli_query($conn, $sql);

header("Location: http://localhost/final/user/CAP/exam/home1.php?id=".$C);
}
else{
 
    
    header("Location: http://localhost/final/user/CAP/exam/home1.php?id=" .$C);
}