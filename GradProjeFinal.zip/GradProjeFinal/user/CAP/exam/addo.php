<?PHP

require "db_conn.php";
$id = $_POST["id"];
$exam = $_POST["exam"];
$grade = $_POST["grade"];
$ttable = mysqli_query($conn, 'SELECT grade FROM exam WHERE  idcourse='.$id);
while ($row = mysqli_fetch_array($ttable)) {
    $s=$s+$row['grade'];
}
 $s+=$grade;
if($grade<=100&& $grade>0 && $s<=100)
{


$sqi = "INSERT INTO exam ( nameexam, grade, idcourse)VALUES('$exam','$grade','$id')";
if ($conn->multi_query($sqi) == TRUE) {
    echo "DATA Insert";
   header('Location:http://localhost/final/user/CAP/exam/home1.php?id='.$id);
}

}
else 
{
  
   
    $message = "the grade <100";
echo "<script type='text/javascript'>alert('$message');</script>";
   header('Location:http://localhost/final/user/CAP/exam/home1.php?id='.$id);  
}
$conn->close();








?>