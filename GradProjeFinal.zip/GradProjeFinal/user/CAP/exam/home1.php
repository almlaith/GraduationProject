<?php include "nav1.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home Exams</title>

</head>

<body>
  <table class="table">
    <thead class="thead-light">

      <tr>
       
        <th >
         Name
        </th>
        <th >
          Grade
        </th>
      </tr>

    </thead>
    <tbody>

      <?php
      $id = (int)$_GET['id'];
      require "db_conn.php";
      $ttable = mysqli_query($conn, 'SELECT * FROM exam WHERE  idcourse=' . $id);


      while ($row = mysqli_fetch_array($ttable)) { ?>
        <tr>
                    <td><?php echo $row['nameexam'] ?> </td>
          <td><?php global $s;
         
          $s=$s+$row['grade'];
          
          echo $row['grade'] ?> </td> 
           
             
          <td><a href="http://localhost/final/user/CAP/exam/editexam.php?id=<?php echo $row['id'] ?>"><button  type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a>

          <td><a href="http://localhost/final/user/CAP/exam/deleteex.php?id=<?php echo $row['id'] ?>"><button type="button" class="btn btn-primary btn-lg btn-block">DELETE</button></a>
          </td>

        </tr>
      <?php } ?>
    </tbody>
  </table>
  



<?php
                                             

if($s==0||$s<100){
?>
    <center><a href="http://localhost/final/user/CAP/exam/add.php?id=<?php echo $id ?>"> <button type="button" class="btn btn-primary btn-lg btn-block">ADD</button></a></center>
 <?php }?>

</body>

</html>