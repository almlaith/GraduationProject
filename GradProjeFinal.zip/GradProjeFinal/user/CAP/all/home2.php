<?php include "nav1.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home Exams</title>

</head>

<body>
  <table class="table">
    <thead class="thead-light">

      <tr>
       
        <th >
         Name
        </th>
        <th >
          Grade
        </th>
        <th >
          close
        </th>
       
      </tr>

    </thead>
    <tbody>

      <?php
      $id = (int)$_GET['id'];
      require "db_conn.php";
      $ttable = mysqli_query($conn, 'SELECT * FROM exam WHERE  idcourse=' . $id);


      while ($row = mysqli_fetch_array($ttable)) { ?>
      <tr>


      </tr>
        <tr>
                    <td><?php echo $row['nameexam'] ?> </td>
          <td><?php        
          echo $row['grade']; ?> </td> 
           
             
          <td><a href="http://localhost/final/user/CAP/all/showcode.php?id=<?php echo $row['id'] ?>"><button  type="button" class="btn btn-primary btn-lg btn-block">Show</button></a>

       
          </td>

        </tr>
      <?php } ?>
    </tbody>
  </table>
  




                 <!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>
  <!-- Bootstrap JS-->
  <script src="vendor/bootstrap-4.1/popper.min.js"></script>
  <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
  <!-- Vendor JS       -->
  <script src="vendor/slick/slick.min.js">
  </script>
  <script src="vendor/wow/wow.min.js"></script>
  <script src="vendor/animsition/animsition.min.js"></script>
  <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
  </script>
  <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
  <script src="vendor/counter-up/jquery.counterup.min.js">
  </script>
  <script src="vendor/circle-progress/circle-progress.min.js"></script>
  <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
  <script src="vendor/chartjs/Chart.bundle.min.js"></script>
  <script src="vendor/select2/select2.min.js">
  </script>                                        



</body>

</html>