<?php
 ob_start();
require "db_conn.php";
$id = $_POST['id'];
$grade = $_POST['grade'];
$ide = $_POST['ide'];

$sql = "UPDATE examclos SET  gradeclos='$grade'    WHERE id=" . $id;
if(mysqli_query($conn, $sql))
{
   // echo $ide;
    header("Location:http://localhost/final/user/CAP/all/showcode.php?id=".$ide);}
    

    ob_end_flush();
?>
