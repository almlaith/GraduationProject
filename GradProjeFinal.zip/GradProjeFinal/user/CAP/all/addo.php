<?PHP

require "db_conn.php";
$id = $_POST["id"];
$clos = $_POST["clos"];
$grade = $_POST["grade"];



$sqi = "INSERT INTO examclos ( idexam, idoutcome, gradeclos)VALUES('$id','$clos','$grade')";
if ($conn->multi_query($sqi) ) {
 
   header('Location:http://localhost/final/user/CAP/all/showcode.php?id='.$id);
}
else{
    echo "DATA Not Insert";
    header('Location:http://localhost/final/user/CAP/all/showcode.php?id='.$id);
}

$conn->close();








?>