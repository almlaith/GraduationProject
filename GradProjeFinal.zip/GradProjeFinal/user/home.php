<?php 
session_start();

if( isset($_SESSION['name'])){
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Fontfaces CSS-->
  <link href="css/font-face.css" rel="stylesheet" media="all">
  <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
  <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
  <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

  <!-- Bootstrap CSS-->
  <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

  <!-- Vendor CSS-->
  <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
  <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
  <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
  <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
  <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
  <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
  <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

  <!-- Main CSS-->
  <link href="css/theme.css" rel="stylesheet" media="all">

  <title>USER</title>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">USER Dashboard </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="http://localhost/final/logout.php">Logout </a>
        </li>

      </ul>

    </div>
  </nav>

  <div class="col-md-12">
    <!-- DATA TABLE -->
    <h3 class="title-5 m-b-35">Course Table</h3>
    <div class="table-data__tool">
      <div class="table-data__tool-left">



      </div>
      <div class="table-data__tool-right">
        <a href="http://localhost/final/user/course/addcourse.php"> <button class="au-btn au-btn-icon au-btn--green au-btn--small">
            <i class="zmdi zmdi-plus"></i>add item</button></a>

      </div>
    </div>
    <div class="table-responsive table-responsive-data2">
      <table class="table table-data2">
        <thead>
          <tr>

            <th>Code</th>
            <th>Course Name</th>
            <th>Hours</th>
            <th>Attend</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php
          
          // $_SESSION['username'] = $row['username'];
          $D = $_SESSION['id'];
          require "db_conn.php";
          $ttable = mysqli_query($conn, 'SELECT * FROM course WHERE userid =' . $D);


          while ($row = mysqli_fetch_array($ttable)) { ?>
            <tr class="tr-shadow" id="<?php echo $row['code']; ?>">

              <td data-target="code"><?php echo $row['code']; ?></td>
              <td data-target="name"><?php echo $row['name']; ?> </td>

              <td data-target="hours"><?php echo $row['hours']; ?></td>
              <td data-target="attend"><?php echo $row['attend']; ?></td>
              <td>
                <div class="table-data-feature">
                  <a href="addall.php?id=<?php echo $row['code'] ?>">
                    <button class="item" data-toggle="tooltip" data-placement="top" title="Send">
                      <i class="zmdi zmdi-mail-send"></i>
                    </button>
                  </a>
                  <a href="editcourse.php?id=<?php echo $row['code'] ?>"><button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                      <i class="zmdi zmdi-edit"></i>
                    </button> </a>
                  <a href="deletcourse.php?id=<?php echo $row['code'] ?>">
                    <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                      <i class="zmdi zmdi-delete"></i>
                    </button></a>
                  <a href="theform.php?id=<?php echo $row['code'] ?>">
                    <button class="item" data-toggle="tooltip" data-placement="top" title="More">
                      <i class="zmdi zmdi-more"></i>
                  </a>
                  </button>
                </div>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
    <!-- END DATA TABLE -->
  </div>
  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" method="POST">
            <h2>update User</h2>




            <div class="form-group">
              <label for="fistName" class="col-sm-3 control-label">username</label>
              <div class="col-sm-9">
                <input type="text" id="username" name="username" placeholder="First Name" class="form-control" autofocus>
              </div>
            </div>


            <div class="form-group">
              <label for="email" class="col-sm-3 control-label">Email* </label>
              <div class="col-sm-9">
                <input type="email" id="email" name="email" placeholder="Email" class="form-control" name="email">
              </div>
            </div>
            <div class="form-group">
              <label for="password" class="col-sm-3 control-label">Password*</label>
              <div class="col-sm-9">
                <input type="text" id="pass" name="pass" placeholder="Password" class="form-control">
              </div>
            </div>
            <div class="form-group">
              <label for="AdminID" class="col-sm-3 control-label">AdminID</label>
              <div class="col-sm-9">
                <input type="text" id="adminID" name="admin" placeholder="AdminID" class="form-control">
              </div>
            </div>
            <div class="form-group">
              <label for="department" class="col-sm-3 control-label">department</label>
              <div class="col-sm-9">
                <input type="text" id="depid" name="department" placeholder="department" class="form-control">
              </div>
            </div>
            <input type="hidden" id="userId" name="id" placeholder="department" class="form-control">




          </form> <!-- /form -->
        </div>
        <div class="modal-footer">
          <a href="#" id="save" class="btn btn-primary pull-right">Update</a>
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>
  <!--===============================================================================================-->

  <script>
    $(document).ready(function() {
      //append values in input fields
      $(document).on('click', 'a[data-role=update]', function() {
        var code = $(this).data('code');
        var code = $('#' + code).children('td[data-target=code]').text();
        var name = $('#' + code).children('td[data-target=name]').text();
        var hours = $('#' + code).children('td[data-target=hours]').text();
        var attend = $('#' + code).children('td[data-target=attend]').text();

        $('#code').val(code);
        $('#name').val(name);
        $('#hours').val(hours);
        $('#attend').val(attend);
        $('#userId').val(code);
        $('#myModal').modal('toggle');




      });

      //new create event to get data from fileds and update in database 

      $('#save').click(function() {
        var id = $('#userId').val();
        var username = $('#username').val();
        var email = $('#email').val();
        var pass = $('#pass').val();
        var adminID = $('#adminID').val();
        var depid = $('#depid').val();
        $.ajax({
          url: 'db_conn.php',
          method: 'post',
          data: {
            username: username,
            email: email,
            pass: pass,
            adminID: adminID,
            depid: depid,
            id: id
          },
          success: function(response) {
            alert(response)
          }

        });
      });
      //================================================================
      $(document).on('click', 'a[data-role=delete]', function() {
        var id = $(this).data('id');
        $clicked_btn = $(this);
        $.ajax({
          url: 'delete-data.php',
          type: 'GET',
          data: {
            'delete': 1,
            'id': id,
          },
          success: function(response) {
            // remove the deleted comment

            $('#username').val(username);
            $('#email').val(email);
            $('#pass').val(pass);
            $('#adminID').val(adminID);
            $('#depid').val(depid);
            $('#userId').val(id);
          }
        });


      });
    });
  </script>
  <!--===============================================================================================-->


  <!-- Jquery JS-->
  <script src="vendor/jquery-3.2.1.min.js"></script>
  <!-- Bootstrap JS-->
  <script src="vendor/bootstrap-4.1/popper.min.js"></script>
  <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
  <!-- Vendor JS       -->
  <script src="vendor/slick/slick.min.js">
  </script>
  <script src="vendor/wow/wow.min.js"></script>
  <script src="vendor/animsition/animsition.min.js"></script>
  <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
  </script>
  <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
  <script src="vendor/counter-up/jquery.counterup.min.js">
  </script>
  <script src="vendor/circle-progress/circle-progress.min.js"></script>
  <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
  <script src="vendor/chartjs/Chart.bundle.min.js"></script>
  <script src="vendor/select2/select2.min.js">
  </script>
</body>

</html>
<?php
}
else {
  header("Location: http://localhost/final/user/accss.php");

}
?>