<?php
$id=$_POST["id"];
$obj=$_POST["obj"];
$sarvername = "localhost";
$uasername = "root";
$pass = "";
$db = "final";

$conn = mysqli_connect($sarvername, $uasername, $pass, $db);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql =   "INSERT INTO objectives( obj, courseid) VALUES ('$obj','$id')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
  header('Location:http://localhost/final/user/opj/home.php?id='.$id);
  
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>


