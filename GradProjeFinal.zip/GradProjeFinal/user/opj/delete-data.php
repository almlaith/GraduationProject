<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $id= (int)$_GET['id'];
     
       require "db_conn.php";
       
       // delete comment fromd database
       if (isset($id)) {
        $ttable = mysqli_query($conn, 'SELECT courseid FROM objectives WHERE id='.$id);
        $row = mysqli_fetch_array($ttable);
         
         
           
           $sql = "DELETE FROM objectives WHERE id=" . $id;
           mysqli_query($conn, $sql);
           
          
          header("Location: http://localhost/final/user/opj/home.php?id=".$row['courseid']);
           exit();
       }
       
       
     ?>
   
</body>
</html>