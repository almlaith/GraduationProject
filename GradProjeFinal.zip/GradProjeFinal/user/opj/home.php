<?php include "nav.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
<table class="table">
  <thead class="thead-light">

    <tr>
      <th scope="col" colspan="4"> <center> OBJECTIVES</center></th>
     
    </tr>
    <tr>
      <th >  OBJECTIVES</th>
      <th >  #</th>
      <th >  #</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $id= (int)$_GET['id'];
          require "db_conn.php";
          $ttable = mysqli_query($conn, 'SELECT * FROM objectives WHERE courseid='.$id);


          while ($row = mysqli_fetch_array($ttable)) { ?>
    <tr >
    <tr colspan="4" >
     
      <td colspan="4"><center><?php echo $row['obj'] ?>  <center></td>
      <td><a href="http://localhost/final/user/opj/editdata.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a></td>
    <td><a href="http://localhost/final/user/opj/delete-data.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">delete</button></a></td>

    </tr>
    <?php } ?>
  </tbody>
</table>


   <center><a href="http://localhost/final/user/opj/adddata.php?id=<?php echo $id ; ?>"><button type="button" class="btn btn-primary btn-lg btn-block">ADD</button></a></center>


</body>
</html>