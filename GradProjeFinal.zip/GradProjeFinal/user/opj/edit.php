<?PHP


require "db_conn.php";
$ide = $_POST["ide"];
$obj = $_POST["obj"];
$sql = "UPDATE objectives SET obj='$obj' WHERE  id=" . $ide;
$ttable = mysqli_query($conn, 'SELECT courseid FROM objectives WHERE id='.$ide);
$row = mysqli_fetch_array($ttable);


if ($conn->multi_query($sql) == TRUE) {
    echo "DATA Insert";
    header('Location:http://localhost/final/user/opj/home.php?id='.$row['courseid']);
}
$conn->close();








?>