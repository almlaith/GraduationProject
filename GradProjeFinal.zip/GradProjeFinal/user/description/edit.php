<?PHP


require "db_conn.php";
$ide = $_POST["ide"];
$dec = $_POST["obj"];
$idc = $_POST["idc"];
$sql = "UPDATE objectives SET obj='$obj' WHERE  id=" . $ide;


if ($conn->multi_query($sql) == TRUE) {
    echo "DATA Insert";
    header('Location:http://localhost/final/user/opj/home.php?id='.$idc);
}
$conn->close();








?>