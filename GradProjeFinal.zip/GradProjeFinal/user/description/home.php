<?php include "nav.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
<table class="table">
  <thead class="thead-light">

    <tr>
      <th scope="col" colspan="4"> <center>Short Description</center></th>
     
    </tr>
    
  </thead>
  <tbody>
  <?php
  $id= (int)$_GET['id'];
          require "db_conn.php";
          $ttable = mysqli_query($conn, 'SELECT * FROM description WHERE courseid='.$id);


          while ($row = mysqli_fetch_array($ttable)) {
            $iddc=$row['id']; ?>
    <tr >
    <tr colspan="4" >
     
      <td colspan="4"><center><?php echo $row['descr'];?>  <center></td>
      
    </tr>
    <?php } ?>
  </tbody>
</table>
<center><a href="http://localhost/final/user/description/editdesc.php?id=<?php echo $iddc ?>"><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a></center>


</body>
</html>