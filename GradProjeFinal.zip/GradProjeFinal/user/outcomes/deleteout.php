<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $S= (int)$_GET['id'];
     
       require "db_conn.php";
       
       // delete comment fromd database
       if (isset($S)) {
           $id = $S;
         
           $ttable = mysqli_query($conn, 'SELECT courseid FROM outcome WHERE  id='.$S);
           $row = mysqli_fetch_array($ttable);
           
           $sql = "DELETE FROM outcome WHERE id=" . $S;
           mysqli_query($conn, $sql);
           
          
          header("Location: http://localhost/final/user/outcomes/home.php?id=".$row['courseid']);
           exit();
       }
       
       
     ?>
   
</body>
</html>