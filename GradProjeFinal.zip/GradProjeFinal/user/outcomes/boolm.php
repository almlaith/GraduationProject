<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bootstrap - Prebuilt Layout</title>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

</head>
<body>

  <div class="container">

  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#glassAnimals">
  Knowledge  </button>  


  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#glassAnimals2">
  Skills  </button>  


  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#glassAnimals3">
  Communication  </button>  

<div>

<div class="modal fade" id="glassAnimals" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Knowledge </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <table class="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
   
    </tr>
  </thead>
  <tbody>
    
     
      <?PHP
     
     require "db_conn.php";
     $ttable = mysqli_query($conn, 'SELECT * FROM bloom WHERE catid=7');


     while ($row2 = mysqli_fetch_array($ttable)) { ?>
    
 

    <td><?php echo $row2['bloomname'] ?> </td>

 
 <?php } ?>
      
   
   
  </tbody>
</table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      
      </div>
    </div>
  </div>
</div>
<!-- end 11111111111-->
<div class="modal fade" id="glassAnimals2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Skills </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <table class="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
   
    </tr>
  </thead>
  <tbody>
    
     
      <?PHP
     
     require "db_conn.php";
     $ttable = mysqli_query($conn, 'SELECT * FROM bloom WHERE catid=8');


     while ($row2 = mysqli_fetch_array($ttable)) { ?>
    
 

    <td><?php echo $row2['bloomname'] ?> </td>

 
 <?php } ?>
      
   
   
  </tbody>
</table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>
<!-- end 22222222222222-->
<div class="modal fade" id="glassAnimals3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Communication</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <table class="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
   
    </tr>
  </thead>
  <tbody>
    
     
      <?PHP
     
     require "db_conn.php";
     $ttable = mysqli_query($conn, 'SELECT * FROM bloom WHERE catid=9');


     while ($row2 = mysqli_fetch_array($ttable)) { ?>
    
 

    <td><?php echo $row2['bloomname'] ?> </td>

 
 <?php } ?>
      
   
   
  </tbody>
</table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<!-- end 3333333333333333333333333333-->
<script>
$("#glassAnimals").click(function() {
  $('#glassAnimals').modal({
    backdrop: 'static'
  });
});
$("#glassAnimals2").click(function() {
  $('#glassAnimals').modal({
    backdrop: 'static'
  });
});
$("#glassAnimals3").click(function() {
  $('#glassAnimals').modal({
    backdrop: 'static'
  });
});
</script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>