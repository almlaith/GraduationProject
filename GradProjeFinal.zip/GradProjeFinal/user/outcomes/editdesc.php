
<!DOCTYPE html>
<html>

<head>
    <title>Educational registration form</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style>
        html,
        body {
            min-height: 100%;
        }

        body,
        div,
        form,
        input,
        select,
        p {
            padding: 0;
            margin: 0;
            outline: none;
            font-family: Roboto, Arial, sans-serif;
            font-size: 16px;
            color: #eee;
        }

        body {
            background: url("/uploads/media/default/0001/01/b5edc1bad4dc8c20291c8394527cb2c5b43ee13c.jpeg") no-repeat center;
            background-size: cover;
        }

        h1,
        h2 {
            text-transform: uppercase;
            font-weight: 400;
        }

        h2 {
            margin: 0 0 0 8px;
        }

        .main-block {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%;
            padding: 25px;
            background: rgba(0, 0, 0, 0.5);
        }

        .left-part,
        form {
            padding: 25px;
        }

        .left-part {
            text-align: center;
        }

        .fa-graduation-cap {
            font-size: 72px;
        }

        form {
            background: rgba(0, 0, 0, 0.7);
        }

        .title {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .info {
            display: flex;
            flex-direction: column;
        }

        input,
        select {
            padding: 5px;
            margin-bottom: 30px;
            background: transparent;
            border: none;
            border-bottom: 1px solid #eee;
        }

        input::placeholder {
            color: #eee;
        }

        option:focus {
            border: none;
        }

        option {
            background: black;
            border: none;
        }

        .checkbox input {
            margin: 0 10px 0 0;
            vertical-align: middle;
        }

        .checkbox a {
            color: #26a9e0;
        }

        .checkbox a:hover {
            color: #85d6de;
        }

        .btn-item,
        button {
            padding: 10px 5px;
            margin-top: 20px;
            border-radius: 5px;
            border: none;
            background: #26a9e0;
            text-decoration: none;
            font-size: 15px;
            font-weight: 400;
            color: #fff;
        }

        .btn-item {
            display: inline-block;
            margin: 20px 5px 0;
        }

        button {
            width: 100%;
        }

        button:hover,
        .btn-item:hover {
            background: #85d6de;
        }

        @media (min-width: 568px) {

            html,
            body {
                height: 100%;
            }

            .main-block {
                flex-direction: row;
                height: calc(100% - 50px);
            }

            .left-part,
            form {
                flex: 1;
                height: auto;
            }
        }
    </style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">USER Dashboard </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <?php $id= (int)$_GET['id'];
           require "db_conn.php";
        $ttable = mysqli_query($conn, 'SELECT courseid FROM outcome WHERE  id='.$id);
        $row = mysqli_fetch_array($ttable);
        $f= $row['courseid'];
         ?>
      
        <a class="nav-link" href="http://localhost/final/user/outcomes/home.php?id=<?php echo $f ?>">Home </a>
      </li>
     
      
    </ul>
   
  </div>
</nav>
    <div class="main-block">
        <div class="left-part">
            <i class="fas fa-graduation-cap"></i>


        </div>
        <?PHP
        $S = (int)$_GET['id'];
        require "db_conn.php";


        $ttable = mysqli_query($conn, 'SELECT * FROM outcome WHERE id=' . $S);


        while ($row = mysqli_fetch_array($ttable)) { ?>
            <form action="edit.php" method="post">
                <div class="title">
                    <i class="fas fa-pencil-alt"></i>
                    <h2>Edit OUTCOME </h2>
                </div>
                <div class="info">
                    <label>Cat Name:</label>
                    <select name="cat1" id="cat1">
                        <?php
                        require "db_conn.php";
                        $ttable1 = mysqli_query($conn, 'SELECT * FROM cat');


                        while ($row1 = mysqli_fetch_array($ttable1)) { ?>



                            <option value="<?php echo $row1['id'];
                                            ?>"><?php echo $row1['name'];
                                                ?></option>


                        <?php } ?>
                    </select>
                    <label>clos</label>
             <select name="cat33" id="cat33">
                <?php
                require "db_conn.php";
 
                $ttable = mysqli_query($conn, 'SELECT * FROM clos ' );


                while ($row2 = mysqli_fetch_array($ttable)) { ?>



                    <option value="<?php echo $row2['id'];
                                    ?>"><?php echo $row2['name'];
                        ?></option>


                <?php } ?>
            </select>
                    <label>cont</label>
                    <input type="text" name="cont1" value="<?php echo $row['cont']; ?>">
                    <input type="hidden" name="cont2" value="<?php echo $S?>">

                </div>

                <center><a> <button  href="" type="submit">Submit</button></a>
            </form>
        <?php }
        ?>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script> 
</body>

</html>

