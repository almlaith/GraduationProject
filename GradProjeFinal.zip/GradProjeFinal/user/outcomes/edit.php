<?php
require "db_conn.php";


$cat1 = $_POST['cat1'];

$clos = $_POST['cat33'];

$cont = $_POST['cont1'];
$cont2=$_POST['cont2'];

$ttable = mysqli_query($conn, 'SELECT courseid FROM outcome WHERE  id='.$cont2);
           $row = mysqli_fetch_array($ttable);

           $sql = "UPDATE outcome SET catname='$cat1' , idclos='$clos' , cont='$cont'   WHERE id=" . $cont2;
           mysqli_query($conn, $sql);
           echo $row['courseid'];
          $f= $row['courseid'];
        
           
          
          header("Location:http://localhost/final/user/outcomes/home.php?id=".$f);
   
    

?>
