<?PHP
require "db_conn.php";
$id = $_POST["id1"];

$cat = $_POST["cat1"];
$close1 = $_POST["cat33"];
$cont = $_POST["cont"];



$sqi = "INSERT INTO outcome ( catname, idclos, cont, courseid)VALUES('$cat','$close1','$cont','$id')";
if ($conn->multi_query($sqi) == TRUE) {
    echo "DATA Insert";
    header('Location:http://localhost/final/user/outcomes/home.php?id='.$id);
}
$conn->close();








?>