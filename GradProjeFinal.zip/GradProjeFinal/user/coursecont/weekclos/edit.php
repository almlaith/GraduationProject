<?php
require "db_conn.php";

$clos=$_POST['clos'];
$idweek=$_POST['idweek'];
$ttable = mysqli_query($conn, 'SELECT idcontent FROM weeklyclose WHERE  id='.$idweek);
$row = mysqli_fetch_array($ttable);
$sql = "UPDATE weeklyclose SET idoutcome='$clos'    WHERE id=" . $idweek;
if(mysqli_query($conn, $sql)){

    header("Location:http://localhost/final/user/coursecont/weekclos/home.php?id=".$row['idcontent']);
}
else{
 
    
    //header("Location: http://localhost/final/user/CAP/exam/home1.php?id=" .$C);
}