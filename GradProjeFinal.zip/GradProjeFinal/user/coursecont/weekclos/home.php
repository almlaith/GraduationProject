<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WEEKLY CLOS</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">USER Dashboard </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <?php
          $id = (int)$_GET['id'];

          require "db_conn.php";
          $ttable = mysqli_query($conn, 'SELECT idcourse FROM contents WHERE  id=' . $id);
          while ($row = mysqli_fetch_array($ttable)) {
            $idc = $row['idcourse'];
          ?>

            <a class="nav-link" href="http://localhost/final/user/coursecont/home.php?id=<?php echo $idc ?>">Home </a>
        </li>

      <?php } ?>
      </ul>

    </div>
  </nav>




  <table class="table">
    <thead class="thead-light table-bordered">

      <tr>
        <th scope="col" colspan="9">
          <center>WEEKLY CLOS </center>
        </th>

      </tr>
      <tr>


        <th scope="col"> clos </th>
        <th scope="col"> # </th>
        <th scope="col"> # </th>
      </tr>
    </thead>
    <tbody>
      <?php
      $id = (int)$_GET['id'];
     
      require "db_conn.php";
      $ttable1 = mysqli_query($conn, 'SELECT * FROM contents WHERE  id=' . $id);
      while ($row1 = mysqli_fetch_array($ttable1)) { 
        require "db_conn.php";
        //$ttable = mysqli_query($conn, 'SELECT * FROM examclos WHERE courseid='.$idco); 
        $ttable = mysqli_query($conn, 'SELECT * FROM weeklyclose WHERE  idcontent='.$id);  
        while ($row = mysqli_fetch_array($ttable)) {?>
        <tr>

      <?php  $idco=$row1['idcourse'];?>
          <td> 
          <?php 
        
           
            $ttable2 = mysqli_query($conn, 'SELECT * FROM outcome WHERE  id='.$row['idoutcome']); 
            while ($row2 = mysqli_fetch_array($ttable2)) {
            
              $ttable3 = mysqli_query($conn, 'SELECT * FROM clos WHERE  id='.$row2['idclos']);
              while ($row3 = mysqli_fetch_array($ttable3)) {
              
                echo $row3 ['name']."      ".$row2 ['cont'] ;}}
          ?>
          </td>
          <?php $S=$row['id'];
          ?>
          <td><a href="http://localhost/final/user/coursecont/weekclos/editweek.php?id=<?php echo $S ?>"><button type="button" class="btn btn-primary btn-lg btn-block">EDIT</button></a>

          <td><a href="http://localhost/final/user/coursecont/weekclos/deleteweek.php?id=<?php echo $S ?>"><button type="button" class="btn btn-primary btn-lg btn-block">DELETE</button></a>
          </td>

        </tr>
      <?php } }?>
    </tbody>
  </table>


  <?php
  if (!isset($row['cont'])) {
  ?>

    <center><a href="http://localhost/final/user/coursecont/weekclos/add.php?id=<?php echo $id ?>"> <button type="button" class="btn btn-primary btn-lg btn-block">ADD</button></a></center>
  <?php
  }
  ?>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>

</html>