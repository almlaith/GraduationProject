<?php
require "db_conn.php";

$clos=$_POST['clos'];
$idweek=$_POST['idweek'];

$sqi = "INSERT INTO weeklyclose ( idcontent, idoutcome)VALUES('$idweek','$clos')";


if(mysqli_query($conn, $sqi)){

    header("Location:http://localhost/final/user/coursecont/weekclos/home.php?id=".$idweek);
}
else{
 
    
    //header("Location: http://localhost/final/user/CAP/exam/home1.php?id=" .$C);
}