<?php
require "db_conn.php";
//`id`, `week`, `houers`, `topics`, `teching`, `assessment`, `idcourse`
$id=$_POST['id'];
$week=$_POST['week'];
$houers=$_POST['houers'];
$topics=$_POST['topics'];
$teching=$_POST['teching'];
$assessment=$_POST['assessment'];
$idcourse=$_POST['idcourse'];
$sql = "UPDATE contents SET week='$week' , houers='$houers' ,topics='$topics',teching='$teching',assessment='$assessment'   WHERE id=" . $id;
if(mysqli_query($conn, $sql)){

header("Location: http://localhost/final/user/coursecont/home.php?id=".$idcourse);
}
else{
 
    
    //header("Location: http://localhost/final/user/CAP/exam/home1.php?id=" .$C);
}