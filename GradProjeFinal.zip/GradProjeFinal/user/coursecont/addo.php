<?php
require "db_conn.php";
$week=$_POST['week'];
$houers=$_POST['houers'];
$topics=$_POST['topics'];
$teching=$_POST['teching'];
$assessment=$_POST['assessment'];
$idcourse=$_POST['idcourse'];
$sqi = "INSERT INTO contents ( week, houers,topics,teching,assessment,idcourse)VALUES('$week','$houers', '$topics', '$teching','$assessment','$idcourse' )";


if(mysqli_query($conn, $sqi)){

    header("Location:http://localhost/final/user/coursecont/home.php?id=".$idcourse);
}
else{
 
    echo "not inSARTO";
    //header("Location: http://localhost/final/user/CAP/exam/home1.php?id=" .$C);
}