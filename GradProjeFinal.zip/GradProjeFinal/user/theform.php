<?php require "db_conn.php";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>index</title>
    <meta name="author" content="Belal" />
    <link rel="stylesheet" href="css1.css">
 
</head>

<body>
    <center>
    <?php $id = (int)$_GET['id'];   
    ?>
    <table style="border-collapse:collapse;margin-left:17.424pt" cellspacing="0">
        <tr style="height:40pt">
            <td style="width:170pt">
                <p class="s1" style="padding-top: 6pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Jadara University</p>
            </td>
            <td style="width:148pt;border-bottom-style:solid;border-bottom-width:1pt" rowspan="2">
                <p style="padding-left: 26pt;text-indent: 0pt;text-align: left;"><span><img width="82" height="94" alt="oemlogo" title="oemlogo" src="images/جامعة-جدارا.png" /></span></p>
            </td>
            <td style="width:141pt">
                <p class="s2" style="padding-left: 59pt;text-indent: 0pt;text-align: left;"> جامعة جدارا</p>
            </td>
        </tr>
        <tr style="height:31pt">
    
            <td style="width:141pt;border-bottom-style:solid;border-bottom-width:1pt">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
        </tr>
    </table>
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <p style="padding-top: 4pt;text-indent: 0pt;text-align: center;">COURSE DESCRIPTIONS</p>
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <!-- ب دايت الجدول الاول معلومات المدرس والمادة -->
    <table style="border-collapse:collapse;margin-left:5.914pt" cellspacing="0">
        <tr style="height:20pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Faculty</p>
            </td>
            <td style="width:396pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="5">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"> <?php
                 
                 $ttable = mysqli_query($conn, 'SELECT userid FROM course WHERE code= '.$id);
                 $row = mysqli_fetch_array($ttable);     
                 $ttable1 = mysqli_query($conn, 'SELECT depid  FROM user WHERE id= '.$row['userid']);   
                 $row1 = mysqli_fetch_array($ttable1);     
                 $ttable2 = mysqli_query($conn, 'SELECT facid  FROM department WHERE id= '.$row1['depid']);   
                 $row2 = mysqli_fetch_array($ttable2);     
                 $ttable3 = mysqli_query($conn, 'SELECT facname  FROM faculty WHERE id= '.$row2['facid']);   
                 $row3 = mysqli_fetch_array($ttable3);  
                 echo $row3['facname'] ;                                
                  
                ?></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Department</p>
            </td>
            <td style="width:244pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="3">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                 
                 $ttable = mysqli_query($conn, 'SELECT userid FROM course WHERE code= '.$id);
                 $row = mysqli_fetch_array($ttable);     
                 $ttable1 = mysqli_query($conn, 'SELECT depid  FROM user WHERE id= '.$row['userid']);   
                 $row1 = mysqli_fetch_array($ttable1);     
                 $ttable2 = mysqli_query($conn, 'SELECT DepName  FROM department WHERE id= '.$row1['depid']);   
                 $row2 = mysqli_fetch_array($ttable2);     
                  
                 echo $row2['DepName'] ;                                
                  
                ?></p>
            </td>
            <td style="width:88pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">NQF level</p>
            </td>
            <td style="width:64pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"></p>
            </td>
        </tr>
        <tr style="height:42pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p class="s4" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Course Title</p>
            </td>
            <td style="width:119pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s4" style="padding-left: 36pt;padding-right: 19pt;text-indent: -15pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT name FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
                echo $row['name'];
                ?>  </p>
            </td>
            <td style="width:69pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p class="s4" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Code</p>
            </td>
            <td style="width:56pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s4" style="padding-top: 6pt;padding-left: 9pt;text-indent: 0pt;text-align: left;"><?php echo $id;?></p>
            </td>
            <td style="width:88pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p class="s4" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Prerequisite</p>
            </td>
            <td style="width:64pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Credit Hours</p>
            </td>
            <td style="width:119pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT hours FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
                echo $row['hours'];
                ?></p>
            </td>
            <td style="width:69pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Theory</p>
            </td>
            <td style="width:56pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT hours FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
                echo $row['hours'];
                ?></p>
            </td>
            <td style="width:88pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Practical</p>
            </td>
            <td style="width:64pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Course Leader</p>
            </td>
            <td style="width:119pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT userid FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
                $ttable1 = mysqli_query($conn, 'SELECT username FROM user WHERE id= '.$row['userid']);
                $row1 = mysqli_fetch_array($ttable1); 
                echo $row1['username'];
                ?></p>
            </td>
            <td style="width:69pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">email</p>
            </td>
            <td style="width:208pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="3">
                <p style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT userid FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
                $ttable1 = mysqli_query($conn, 'SELECT email FROM user WHERE id= '.$row['userid']);
                $row1 = mysqli_fetch_array($ttable1); 
                echo $row1['email'];
                ?></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Lecturers</p>
            </td>
            <td style="width:119pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT userid FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
                $ttable1 = mysqli_query($conn, 'SELECT username FROM user WHERE id= '.$row['userid']);
                $row1 = mysqli_fetch_array($ttable1); 
                echo $row1['username'];
                ?></p>
            </td>
            <td style="width:69pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">emails</p>
            </td>
            <td style="width:208pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="3">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Lecture time</p>
            </td>
            <td style="width:119pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"></p>
            </td>
            <td style="width:69pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Classroom</p>
            </td>
            <td style="width:208pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="3">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT attend FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
               
                echo $row['attend'];
                ?></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:91pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Semester</p>
            </td>
            <td style="width:119pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"></p>
            </td>
            <td style="width:69pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Production</p>
            </td>
            <td style="width:65pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
           
            <td style="width:71pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:20pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Awards</p>
            </td>
            <td style="width:253pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="3">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
            <td style="width:72pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Attendance</p>
            </td>
            <td style="width:71pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php
                $ttable = mysqli_query($conn, 'SELECT attend FROM course WHERE code= '.$id);
                $row = mysqli_fetch_array($ttable); 
               
                echo $row['attend'];
                ?></p>
            </td>
        </tr>
    </table>
    <!--الجدول الاول معلومات المدرس والمادة تم-->
    <!--الجدول الاول معلومات المدرس والمادة تم-->
    <!--الجدول الاول معلومات المدرس والمادة تم-->
    <!--==========================================================================-->
     <!--جدول الوصف والابوجكتف -->
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <table style="border-collapse:collapse;margin-left:5.914pt" cellspacing="0">
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 3pt;padding-left: 198pt;text-indent: 0pt;text-align: left;">Short Description</p>
            </td>
        </tr>
        <tr style="height:56pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-left: 5pt;padding-right: 4pt;text-indent: 0pt;text-align: justify;"><span>
                <?php
                $ttable = mysqli_query($conn, 'SELECT descr FROM description WHERE courseid= '.$id);
                $row = mysqli_fetch_array($ttable); 
               
                echo $row['descr'];
                ?>
                </span></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s4" style="padding-top: 2pt;padding-left: 196pt;text-indent: 0pt;text-align: left;">Course Objectives</p>
            </td>
        </tr>
        <tr style="height:102pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                                    
                
                  <ol>
                  <?php
                $ttable = mysqli_query($conn, 'SELECT obj FROM objectives WHERE courseid= '.$id);
                while($row = mysqli_fetch_array($ttable)){ ?>
                <li><?php echo $row['obj'];?></li>
               
                <?php }?>
              </ol>

            </td>
        </tr>
    </table>
       <!--==========================================================================-->
     <!--جدول الوصف outcomes -->
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <table style="border-collapse:collapse;margin-left:5.914pt" cellspacing="0">
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 192pt;padding-right: 190pt;text-indent: 0pt;text-align: center;">Learning Outcomes</p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">A. Knowledge - Theoretical Understanding</p>
            </td>
        </tr>
        <tr style="height:52pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s7" style="padding-left: 5pt;text-indent: 0pt;line-height: 12pt;text-align: justify;">   <?php
                
                $ttable = mysqli_query($conn, 'SELECT cont,idclos FROM outcome WHERE catname=3 AND courseid= '.$id );
               
              while(  $row = mysqli_fetch_array($ttable)){
                $ttable1 = mysqli_query($conn, 'SELECT name FROM clos WHERE id= '. $row['idclos'] );
                while(  $row1 = mysqli_fetch_array($ttable1)){
                     echo $row1['name']."   ".$row['cont']."<br>";
                }
               }
               
                
                ?></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">B. Knowledge - Practical Application</p>
            </td>
        </tr>
        <tr style="height:27pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
               
                <p class="s7" style="padding-left: 5pt;text-indent: 0pt;line-height: 12pt;text-align: left;">
                <?php
                
                $ttable = mysqli_query($conn, 'SELECT cont,idclos FROM outcome WHERE catname=4 AND courseid= '.$id );
               
              while(  $row = mysqli_fetch_array($ttable)){
                $ttable1 = mysqli_query($conn, 'SELECT name FROM clos WHERE id= '. $row['idclos'] );
                while(  $row1 = mysqli_fetch_array($ttable1)){
                     echo $row1['name']."   ".$row['cont']."<br>";
                }
               }
               
                
                ?>
            </p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">C. Skills - Generic Problem Solving and Analytical Skills</p>
            </td>
        </tr>
        <tr style="height:28pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s4" style="padding-left: 5pt;text-indent: 0pt;line-height: 13pt;text-align: left;"><?php
                
                $ttable = mysqli_query($conn, 'SELECT cont,idclos FROM outcome WHERE catname=5 AND courseid= '.$id );
               
              while(  $row = mysqli_fetch_array($ttable)){
                $ttable1 = mysqli_query($conn, 'SELECT name FROM clos WHERE id= '. $row['idclos'] );
                while(  $row1 = mysqli_fetch_array($ttable1)){
                     echo $row1['name']."   ".$row['cont']."<br>";
                }
               }
               
                
                ?></p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">D. Skills - Communication, ICT, and Numeracy</p>
            </td>
        </tr>
    </table>
    <table style="border-collapse:collapse;margin-left:5.914pt" cellspacing="0">
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p style="text-indent: 0pt;text-align: left;"><br />
                <?php
                
                $ttable = mysqli_query($conn, 'SELECT cont,idclos FROM outcome WHERE catname=6 AND courseid= '.$id );
               
              while(  $row = mysqli_fetch_array($ttable)){
                $ttable1 = mysqli_query($conn, 'SELECT name FROM clos WHERE id= '. $row['idclos'] );
                while(  $row1 = mysqli_fetch_array($ttable1)){
                     echo $row1['name']."   ".$row['cont']."<br>";
                }
               }
               
                
                ?>
            </p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">E. Competence: Autonomy, Responsibility, and Context</p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s7" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><span class="s5"> <?php
                
                $ttable = mysqli_query($conn, 'SELECT cont,idclos FROM outcome WHERE catname=7 AND courseid= '.$id );
               
              while(  $row = mysqli_fetch_array($ttable)){
                $ttable1 = mysqli_query($conn, 'SELECT name FROM clos WHERE id= '. $row['idclos'] );
                while(  $row1 = mysqli_fetch_array($ttable1)){
                     echo $row1['name']."   ".$row['cont']."<br>";
                }
               }
               
                
                ?></p>
            </td>
        </tr>
      
      
      
     
    </table>
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <table style="border-collapse:collapse;margin-left:5.914pt" cellspacing="0">
        <tr style="height:20pt">
            <td style="width:489pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="6" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 3pt;padding-left: 200pt;padding-right: 199pt;text-indent: 0pt;text-align: center;">Course Contents</p>
            </td>
        </tr>
        <tr style="height:28pt">
            <td style="width:42pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 6pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Week</p>
            </td>
            <td style="width:43pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 6pt;padding-left: 4pt;padding-right: 3pt;text-indent: 0pt;text-align: center;">Hours</p>
            </td>
            <td style="width:42pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 6pt;padding-left: 4pt;padding-right: 4pt;text-indent: 0pt;text-align: center;">CLOs</p>
            </td>
            <td style="width:185pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-top: 6pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Topics</p>
            </td>
            <td style="width:106pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-left: 5pt;text-indent: 0pt;line-height: 14pt;text-align: left;"><span>Teaching Learning Methods</span></p>
            </td>
            <td style="width:71pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s4" style="padding-left: 5pt;padding-right: 5pt;text-indent: 0pt;line-height: 14pt;text-align: left;"><span>Assessment<br />Methods</span></p>
            </td>
        </tr>
        <?php 
           $ttable = mysqli_query($conn, 'SELECT * FROM contents WHERE idcourse= '.$id );
               
           while(  $row = mysqli_fetch_array($ttable)){
        ?>
        <tr style="height:26pt">
            <td style="width:42pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-top: 5pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php echo $row['week']?></p>
            </td>
            <td style="width:43pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-left: 1pt;text-indent: 0pt;line-height: 14pt;text-align: center;"><?php echo $row['houers']?></p>
            </td>
            <td style="width:42pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-left: 4pt;padding-right: 3pt;text-indent: 0pt;line-height: 14pt;text-align: center;"><?php 
                   $ttable1 = mysqli_query($conn, 'SELECT idoutcome FROM weeklyclose WHERE idcontent= '.$row['id'] );               
                   while($row1 = mysqli_fetch_array($ttable1)) {
                   
                     $ttable2 = mysqli_query($conn, 'SELECT idclos FROM outcome WHERE id= '.$row1['idoutcome'] );
                     while($row2 = mysqli_fetch_array($ttable2)) {               
                    
                     $ttable3 = mysqli_query($conn, 'SELECT * FROM clos WHERE id= '.$row2['idclos'] );               
                     while($row3 = mysqli_fetch_array($ttable3)) {
                         echo $row3['name']."<br>";
                     
                     }}}
                
                   
                
                
                
                ?></p>
            </td>
            <td style="width:185pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s3" style="padding-left: 4pt;text-indent: 0pt;text-align: left;"><?php echo $row['topics']?></p>
            </td>
            <td style="width:106pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-left: 10pt;padding-right: 9pt;text-indent: 0pt;line-height: 14pt;text-align: center;"><?php echo $row['teching']?></p>
            </td>
            <td style="width:71pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s5" style="padding-left: 6pt;padding-right: 4pt;text-indent: 0pt;line-height: 14pt;text-align: center;"><?php echo $row['assessment']?></p>
            </td>
        </tr>
        <?php }?>
        </tr>
  
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <table style="border-collapse:collapse;margin-left:6.894pt" cellspacing="0">
        <tr style="height:20pt">
            <td style="width:485pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="8" bgcolor="#D9D9D9">
                <p class="s6" style="padding-top: 1pt;padding-left: 168pt;padding-right: 167pt;text-indent: 0pt;text-align: center;">Course Assessment Plan</p>
            </td>
        </tr>
        <tr style="height:19pt">
            <td style="width:219pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2" rowspan="2" bgcolor="#D9D9D9">
                <p class="s6" style="padding-top: 11pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Assessment Method</p>
            </td>
            <td style="width:68pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" rowspan="2" bgcolor="#D9D9D9">
                <p class="s6" style="padding-top: 11pt;padding-left: 15pt;text-indent: 0pt;text-align: left;">Grade</p>
            </td>
            <td style="width:198pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="5" bgcolor="#D9D9D9">
                <p class="s6" style="padding-top: 1pt;padding-left: 79pt;padding-right: 79pt;text-indent: 0pt;text-align: center;">CLOs</p>
            </td>
        </tr>
        <tr style="height:20pt">
        <?php 
        $ttable1 = mysqli_query($conn, 'SELECT idclos FROM outcome WHERE courseid= '.$id );               
        while($row1 = mysqli_fetch_array($ttable1)) {
            $ttable2 = mysqli_query($conn, 'SELECT name FROM clos WHERE id= '.$row1['idclos'] );   
            while($row2 = mysqli_fetch_array($ttable2)) {
        
        ?>
            <td style="width:39pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#D9D9D9">
                <p class="s2" style="padding-top: 2pt;padding-left: 12pt;padding-right: 12pt;text-indent: 0pt;text-align: center;"><?php echo $row2['name']?></p>
            </td>
          
            <?php }}?>
        </tr>
        <?php 
      
        $ttable1 = mysqli_query($conn, 'SELECT * FROM exam WHERE idcourse= '.$id );               
        while($row1 = mysqli_fetch_array($ttable1)) {
            
        
        ?>
        <tr style="height:20pt">
            <td style="width:219pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="2" bgcolor="#D9D9D9">
                <p class="s1" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><?php echo $row1['nameexam']?></p>
            </td>
            <td style="width:68pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s2" style="padding-top: 2pt;padding-right: 27pt;text-indent: 0pt;text-align: right;"><?php echo $row1['grade']?></p>
            </td>
            <?php 
               $ttable2 = mysqli_query($conn, 'SELECT * FROM examclos WHERE idexam= '.$row1['id'] );               
               while($row2 = mysqli_fetch_array($ttable2)) {
            ?>
            <td style="width:39pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s2" style="padding-top: 2pt;text-indent: 0pt;text-align: center;"><?php echo $row2['gradeclos']?></p>
            </td>
          
            <?php }?>
        </tr>
        <?php  }?>
       
    
 
        </tr>
    </table>
   
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <table style="border-collapse:collapse;margin-left:5.914pt" cellspacing="0">
        <tr style="height:20pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" bgcolor="#DFDFDF">
                <p class="s1" style="padding-top: 2pt;padding-left: 215pt;padding-right: 214pt;text-indent: 0pt;text-align: center;">Plagiarism</p>
            </td>
        </tr>
        <tr style="height:104pt">
            <td style="width:487pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt">
                <p class="s7" style="padding-left: 5pt;padding-right: 4pt;text-indent: 0pt;text-align: justify;"><span>Plagiarism is claiming that someone else&#39;s work is your own. The department has a strict policy regarding plagiarism<br />and, if plagiarism is indeed discovered, this policy will be applied. Note that punishments apply also to anyone assisting<br />another to commit plagiarism (for example by knowingly allowing someone to copy your code).</span></p>
                <p class="s7" style="padding-left: 5pt;padding-right: 4pt;text-indent: 0pt;text-align: justify;"><span>Plagiarism is different from group work in which a number of individuals share ideas on how to carry out the coursework.<br />You are strongly encouraged to work in small groups, and you will certainly not be penalized for doing so. This means<br />that you may work together on the program. What is important is that you have a full understanding of all aspects of the<br />completed program. In order to allow proper assessment that this is indeed the case, you must adhere strictly to the</span></p>
                <p class="s7" style="padding-left: 5pt;padding-right: 4pt;text-indent: 0pt;line-height: 12pt;text-align: justify;"><span>course work requirements as outlined above and detailed in the coursework problem description. These requirements<br />are in place to encourage individual understanding, facilitate individual assessment, and deter plagiarism.</span></p>
            </td>
        </tr>
    </table>  
    
    <center>
    <button onclick="window.print()">Print this page</button>
</body>

</html>