<div id="page_content"><a class="hide" id="update_recent_tables" href="index.php?route=/recent-table&amp;ajax_request=1&amp;recent_table=1"></a><div id="page_settings_modal"><div class="page_settings"><form method="post" action="index.php?route=%2Ftable%2Fchange&amp;db=final&amp;table=contents&amp;server=1" class="config-form disableAjax">
  <input type="hidden" name="tab_hash" value="">
      <input type="hidden" name="check_page_refresh" id="check_page_refresh" value="">
    <input type="hidden" name="token" value="35593a7b5d2d3f7a38664d356652283f">
  <input type="hidden" name="submit_save" value="Edit">
<ul class="tabs responsivetable row">
      <li class="active"><a href="#Edit">Edit mode</a></li>
      <li><a href="#Text_fields">Text fields</a></li>
  </ul>
<div class="tabs_contents col">
<fieldset class="optbox" id="Edit" style="">
<legend>Edit mode</legend>
    <p>Customize edit mode.</p>
<table class="pma-table" width="100%" cellspacing="0">
<tbody><tr><th><label for="ProtectBinary">Protect binary columns</label><span class="doc"><a href="./doc/html/config.html#cfg_ProtectBinary" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Disallow BLOB and BINARY columns from editing.</small></th><td><select class="w-75" name="ProtectBinary" id="ProtectBinary"><option value="0">no</option><option value="blob" selected="selected">blob</option><option value="noblob">noblob</option><option value="all">all</option></select><a class="restore-default hide" href="#ProtectBinary" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ShowFunctionFields">Show function fields</label><span class="doc"><a href="./doc/html/config.html#cfg_ShowFunctionFields" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Display the function fields in edit/insert mode.</small></th><td><span class="checkbox"><input type="checkbox" name="ShowFunctionFields" id="ShowFunctionFields" checked="checked"></span><a class="restore-default hide" href="#ShowFunctionFields" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ShowFieldTypesInDataEditView">Show field types</label><span class="doc"><a href="./doc/html/config.html#cfg_ShowFieldTypesInDataEditView" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Defines whether or not type fields should be initially displayed in edit/insert mode.</small></th><td><span class="checkbox"><input type="checkbox" name="ShowFieldTypesInDataEditView" id="ShowFieldTypesInDataEditView" checked="checked"></span><a class="restore-default hide" href="#ShowFieldTypesInDataEditView" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="InsertRows">Number of inserted rows</label><span class="doc"><a href="./doc/html/config.html#cfg_InsertRows" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>How many rows can be inserted at one time.</small></th><td><input type="number" name="InsertRows" id="InsertRows" value="2"><a class="restore-default hide" href="#InsertRows" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ForeignKeyDropdownOrder">Foreign key dropdown order</label><span class="doc"><a href="./doc/html/config.html#cfg_ForeignKeyDropdownOrder" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Sort order for items in a foreign-key dropdown box; <kbd>content</kbd> is the referenced data, <kbd>id</kbd> is the key value.</small></th><td><textarea cols="35" rows="5" name="ForeignKeyDropdownOrder" id="ForeignKeyDropdownOrder">content-id
id-content</textarea><a class="restore-default hide" href="#ForeignKeyDropdownOrder" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ForeignKeyMaxLimit">Foreign key limit</label><span class="doc"><a href="./doc/html/config.html#cfg_ForeignKeyMaxLimit" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>A dropdown will be used if fewer items are present.</small></th><td><input type="number" name="ForeignKeyMaxLimit" id="ForeignKeyMaxLimit" value="100"><a class="restore-default hide" href="#ForeignKeyMaxLimit" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
<fieldset class="optbox" id="Text_fields" style="display: none;">
<legend>Text fields</legend>
    <p>Customize text input fields.</p>
<table class="pma-table" width="100%" cellspacing="0">
<tbody><tr><th><label for="CharEditing">CHAR columns editing</label><span class="doc"><a href="./doc/html/config.html#cfg_CharEditing" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Defines which type of editing controls should be used for CHAR and VARCHAR columns; <kbd>input</kbd> - allows limiting of input length, <kbd>textarea</kbd> - allows newlines in columns.</small></th><td><select class="w-75" name="CharEditing" id="CharEditing"><option value="input" selected="selected">input</option><option value="textarea">textarea</option></select><a class="restore-default hide" href="#CharEditing" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="MinSizeForInputField">Minimum size for input field</label><span class="doc"><a href="./doc/html/config.html#cfg_MinSizeForInputField" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Defines the minimum size for input fields generated for CHAR and VARCHAR columns.</small></th><td><input type="number" name="MinSizeForInputField" id="MinSizeForInputField" value="4"><a class="restore-default hide" href="#MinSizeForInputField" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="MaxSizeForInputField">Maximum size for input field</label><span class="doc"><a href="./doc/html/config.html#cfg_MaxSizeForInputField" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Defines the maximum size for input fields generated for CHAR and VARCHAR columns.</small></th><td><input type="number" name="MaxSizeForInputField" id="MaxSizeForInputField" value="60"><a class="restore-default hide" href="#MaxSizeForInputField" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="CharTextareaCols">CHAR textarea columns</label><span class="doc"><a href="./doc/html/config.html#cfg_CharTextareaCols" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Number of columns for CHAR/VARCHAR textareas.</small></th><td><input type="number" name="CharTextareaCols" id="CharTextareaCols" value="40"><a class="restore-default hide" href="#CharTextareaCols" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="CharTextareaRows">CHAR textarea rows</label><span class="doc"><a href="./doc/html/config.html#cfg_CharTextareaRows" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Number of rows for CHAR/VARCHAR textareas.</small></th><td><input type="number" name="CharTextareaRows" id="CharTextareaRows" value="2"><a class="restore-default hide" href="#CharTextareaRows" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="TextareaCols">Textarea columns</label><span class="doc"><a href="./doc/html/config.html#cfg_TextareaCols" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Textarea size (columns) in edit mode, this value will be emphasized for SQL query textareas (*2).</small></th><td><input type="number" name="TextareaCols" id="TextareaCols" value="40"><a class="restore-default hide" href="#TextareaCols" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="TextareaRows">Textarea rows</label><span class="doc"><a href="./doc/html/config.html#cfg_TextareaRows" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Textarea size (rows) in edit mode, this value will be emphasized for SQL query textareas (*2).</small></th><td><input type="number" name="TextareaRows" id="TextareaRows" value="15"><a class="restore-default hide" href="#TextareaRows" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="LongtextDoubleTextarea">Bigger textarea for LONGTEXT</label><span class="doc"><a href="./doc/html/config.html#cfg_LongtextDoubleTextarea" target="documentation"><img src="themes/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Double size of textarea for LONGTEXT columns.</small></th><td><span class="checkbox"><input type="checkbox" name="LongtextDoubleTextarea" id="LongtextDoubleTextarea" checked="checked"></span><a class="restore-default hide" href="#LongtextDoubleTextarea" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="themes/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
</div>
</form>
<script type="text/javascript">
    if (typeof configInlineParams === 'undefined' || !Array.isArray(configInlineParams)) {
        configInlineParams = [];
    }
    configInlineParams.push(function () {
        registerFieldValidator('InsertRows', 'validatePositiveNumber', true);
registerFieldValidator('ForeignKeyMaxLimit', 'validatePositiveNumber', true);
registerFieldValidator('MinSizeForInputField', 'validateNonNegativeNumber', true);
registerFieldValidator('MaxSizeForInputField', 'validatePositiveNumber', true);
registerFieldValidator('CharTextareaCols', 'validatePositiveNumber', true);
registerFieldValidator('CharTextareaRows', 'validatePositiveNumber', true);
registerFieldValidator('TextareaCols', 'validatePositiveNumber', true);
registerFieldValidator('TextareaRows', 'validatePositiveNumber', true);
$.extend(Messages, {
	'error_nan_p': 'Not a positive number!',
	'error_nan_nneg': 'Not a non-negative number!',
	'error_incorrect_port': 'Not a valid port number!',
	'error_invalid_value': 'Incorrect value!',
	'error_value_lte': 'Value must be less than or equal to %s!'});
$.extend(defaultValues, {
	'ProtectBinary': ['blob'],
	'ShowFunctionFields': true,
	'ShowFieldTypesInDataEditView': true,
	'InsertRows': '2',
	'ForeignKeyDropdownOrder': 'content-id\nid-content',
	'ForeignKeyMaxLimit': '100',
	'CharEditing': ['input'],
	'MinSizeForInputField': '4',
	'MaxSizeForInputField': '60',
	'CharTextareaCols': '40',
	'CharTextareaRows': '2',
	'TextareaCols': '40',
	'TextareaRows': '15',
	'LongtextDoubleTextarea': true});
    });
    if (typeof configScriptLoaded !== 'undefined' && configInlineParams) {
        loadInlineConfig();
    }
</script>
</div></div><form id="insertForm" class="lock-page " method="post" action="index.php?route=/table/replace" name="insertForm" enctype="multipart/form-data" novalidate="novalidate"><input type="hidden" name="db" value="final"><input type="hidden" name="table" value="contents"><input type="hidden" name="goto" value="index.php?route=/table/sql"><input type="hidden" name="err_url" value="index.php?route=/table/sql&amp;db=final&amp;table=contents"><input type="hidden" name="sql_query" value=""><input type="hidden" name="token" value="35593a7b5d2d3f7a38664d356652283f"><div class="responsivetable"><table class="pma-table insertRowTable topmargin"><thead><tr><th>Column</th><th><a href="index.php?route=/table/change" data-post="db=final&amp;table=contents&amp;server=1&amp;ShowFieldTypesInDataEditView=0&amp;ShowFunctionFields=1&amp;goto=index.php%3Froute%3D%2Fsql" title="Hide">Type</a></th><th><a href="index.php?route=/table/change" data-post="db=final&amp;table=contents&amp;server=1&amp;ShowFunctionFields=0&amp;ShowFieldTypesInDataEditView=1&amp;goto=index.php%3Froute%3D%2Fsql" title="Hide">Function</a></th><th>Null</th><th class="fillPage">Value</th></tr></thead> <tfoot><tr><th colspan="5" class="tblFooters right"><input class="btn btn-primary" type="submit" value="Go"></th></tr></tfoot><tbody><tr class="noclick"><td class="text-center">id<input type="hidden" name="fields_name[multi_edit][0][b80bb7740288fda1f201890375a60c8f]" value="id"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">int(11)</span></td><td>
<select name="funcs[multi_edit][0][b80bb7740288fda1f201890375a60c8f]" onchange="return verificationsAfterFieldChange('b80bb7740288fda1f201890375a60c8f', '0','int(11)')" tabindex="3001" id="field_1_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="int" data-decimals="11">
<span class="default_value hide"></span>
<input type="text" name="fields[multi_edit][0][b80bb7740288fda1f201890375a60c8f]" value="" size="11" min="-2147483648" max="2147483647" data-type="INT" class="textfield" onchange="return verificationsAfterFieldChange('b80bb7740288fda1f201890375a60c8f', '0','int(11)')" tabindex="1" id="field_1_3"><input type="hidden" name="auto_increment[multi_edit][0][b80bb7740288fda1f201890375a60c8f]" value="1"></td></tr><tr class="noclick"><td class="text-center">houers<input type="hidden" name="fields_name[multi_edit][0][982d2f9b96480b8e9e698bcdcd888501]" value="houers"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">int(11)</span></td><td>
<select name="funcs[multi_edit][0][982d2f9b96480b8e9e698bcdcd888501]" onchange="return verificationsAfterFieldChange('982d2f9b96480b8e9e698bcdcd888501', '0','int(11)')" tabindex="3002" id="field_2_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="int" data-decimals="11">
<span class="default_value hide"></span>
<input type="text" name="fields[multi_edit][0][982d2f9b96480b8e9e698bcdcd888501]" value="" size="11" min="-2147483648" max="2147483647" data-type="INT" class="textfield" onchange="return verificationsAfterFieldChange('982d2f9b96480b8e9e698bcdcd888501', '0','int(11)')" tabindex="2" id="field_2_3"></td></tr><tr class="noclick"><td class="text-center">topics<input type="hidden" name="fields_name[multi_edit][0][e329b27943961ccab9dc7a8ac2edb666]" value="topics"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">text</span></td><td>
<select name="funcs[multi_edit][0][e329b27943961ccab9dc7a8ac2edb666]" onchange="return verificationsAfterFieldChange('e329b27943961ccab9dc7a8ac2edb666', '0','text')" tabindex="3003" id="field_3_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="text" data-decimals="0">
<span class="default_value hide"></span>
<textarea name="fields[multi_edit][0][e329b27943961ccab9dc7a8ac2edb666]" class="" rows="15" cols="40" dir="ltr" id="field_3_3" onchange="return verificationsAfterFieldChange('e329b27943961ccab9dc7a8ac2edb666', '0','text')" tabindex="3" data-type="CHAR"></textarea>
</td></tr><tr class="noclick"><td class="text-center">teching<input type="hidden" name="fields_name[multi_edit][0][a9ee83145cafb4ab8da5d9f67c5b4b57]" value="teching"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">varchar(100)</span></td><td>
<select name="funcs[multi_edit][0][a9ee83145cafb4ab8da5d9f67c5b4b57]" onchange="return verificationsAfterFieldChange('a9ee83145cafb4ab8da5d9f67c5b4b57', '0','varchar(100)')" tabindex="3004" id="field_4_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="varchar" data-decimals="100">
<span class="default_value hide"></span>


<textarea name="fields[multi_edit][0][a9ee83145cafb4ab8da5d9f67c5b4b57]" class="char charField" data-maxlength="100" rows="7" cols="40" dir="ltr" id="field_4_3" onchange="return verificationsAfterFieldChange('a9ee83145cafb4ab8da5d9f67c5b4b57', '0','varchar(100)')" tabindex="4" data-type="CHAR"></textarea></td></tr><tr class="noclick"><td class="text-center">assessment<input type="hidden" name="fields_name[multi_edit][0][5096c410d87f661b9d8422246dcd2e89]" value="assessment"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">varchar(100)</span></td><td>
<select name="funcs[multi_edit][0][5096c410d87f661b9d8422246dcd2e89]" onchange="return verificationsAfterFieldChange('5096c410d87f661b9d8422246dcd2e89', '0','varchar(100)')" tabindex="3005" id="field_5_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="varchar" data-decimals="100">
<span class="default_value hide"></span>


<textarea name="fields[multi_edit][0][5096c410d87f661b9d8422246dcd2e89]" class="char charField" data-maxlength="100" rows="7" cols="40" dir="ltr" id="field_5_3" onchange="return verificationsAfterFieldChange('5096c410d87f661b9d8422246dcd2e89', '0','varchar(100)')" tabindex="5" data-type="CHAR"></textarea>  </td></tr></tbody></table></div><br><div class="clearfloat"></div><input type="checkbox" checked="checked" name="insert_ignore_1" id="insert_ignore_1"><label for="insert_ignore_1">Ignore</label><br>
<div class="responsivetable"><table class="pma-table insertRowTable topmargin"><thead><tr><th>Column</th><th><a href="index.php?route=/table/change" data-post="db=final&amp;table=contents&amp;server=1&amp;ShowFieldTypesInDataEditView=0&amp;ShowFunctionFields=1&amp;goto=index.php%3Froute%3D%2Fsql" title="Hide">Type</a></th><th><a href="index.php?route=/table/change" data-post="db=final&amp;table=contents&amp;server=1&amp;ShowFunctionFields=0&amp;ShowFieldTypesInDataEditView=1&amp;goto=index.php%3Froute%3D%2Fsql" title="Hide">Function</a></th><th>Null</th><th class="fillPage">Value</th></tr></thead> <tfoot><tr><th colspan="5" class="tblFooters right"><input class="btn btn-primary" type="submit" value="Go"></th></tr></tfoot><tbody><tr class="noclick"><td class="text-center">id<input type="hidden" name="fields_name[multi_edit][1][b80bb7740288fda1f201890375a60c8f]" value="id"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">int(11)</span></td><td>
<select name="funcs[multi_edit][1][b80bb7740288fda1f201890375a60c8f]" onchange="return verificationsAfterFieldChange('b80bb7740288fda1f201890375a60c8f', '1','int(11)')" tabindex="3006" id="field_6_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="int" data-decimals="11">
<span class="default_value hide"></span>
<input type="text" name="fields[multi_edit][1][b80bb7740288fda1f201890375a60c8f]" value="" size="11" min="-2147483648" max="2147483647" data-type="INT" class="textfield" onchange="return verificationsAfterFieldChange('b80bb7740288fda1f201890375a60c8f', '1','int(11)')" tabindex="6" id="field_6_3"><input type="hidden" name="auto_increment[multi_edit][1][b80bb7740288fda1f201890375a60c8f]" value="1"></td></tr><tr class="noclick"><td class="text-center">houers<input type="hidden" name="fields_name[multi_edit][1][982d2f9b96480b8e9e698bcdcd888501]" value="houers"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">int(11)</span></td><td>
<select name="funcs[multi_edit][1][982d2f9b96480b8e9e698bcdcd888501]" onchange="return verificationsAfterFieldChange('982d2f9b96480b8e9e698bcdcd888501', '1','int(11)')" tabindex="3007" id="field_7_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="int" data-decimals="11">
<span class="default_value hide"></span>
<input type="text" name="fields[multi_edit][1][982d2f9b96480b8e9e698bcdcd888501]" value="" size="11" min="-2147483648" max="2147483647" data-type="INT" class="textfield" onchange="return verificationsAfterFieldChange('982d2f9b96480b8e9e698bcdcd888501', '1','int(11)')" tabindex="7" id="field_7_3"></td></tr><tr class="noclick"><td class="text-center">topics<input type="hidden" name="fields_name[multi_edit][1][e329b27943961ccab9dc7a8ac2edb666]" value="topics"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">text</span></td><td>
<select name="funcs[multi_edit][1][e329b27943961ccab9dc7a8ac2edb666]" onchange="return verificationsAfterFieldChange('e329b27943961ccab9dc7a8ac2edb666', '1','text')" tabindex="3008" id="field_8_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="text" data-decimals="0">
<span class="default_value hide"></span>
<textarea name="fields[multi_edit][1][e329b27943961ccab9dc7a8ac2edb666]" class="" rows="15" cols="40" dir="ltr" id="field_8_3" onchange="return verificationsAfterFieldChange('e329b27943961ccab9dc7a8ac2edb666', '1','text')" tabindex="8" data-type="CHAR"></textarea>
</td></tr><tr class="noclick"><td class="text-center">teching<input type="hidden" name="fields_name[multi_edit][1][a9ee83145cafb4ab8da5d9f67c5b4b57]" value="teching"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">varchar(100)</span></td><td>
<select name="funcs[multi_edit][1][a9ee83145cafb4ab8da5d9f67c5b4b57]" onchange="return verificationsAfterFieldChange('a9ee83145cafb4ab8da5d9f67c5b4b57', '1','varchar(100)')" tabindex="3009" id="field_9_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="varchar" data-decimals="100">
<span class="default_value hide"></span>


<textarea name="fields[multi_edit][1][a9ee83145cafb4ab8da5d9f67c5b4b57]" class="char charField" data-maxlength="100" rows="7" cols="40" dir="ltr" id="field_9_3" onchange="return verificationsAfterFieldChange('a9ee83145cafb4ab8da5d9f67c5b4b57', '1','varchar(100)')" tabindex="9" data-type="CHAR"></textarea></td></tr><tr class="noclick"><td class="text-center">assessment<input type="hidden" name="fields_name[multi_edit][1][5096c410d87f661b9d8422246dcd2e89]" value="assessment"></td><td class="text-center nowrap"><span class="column_type" dir="ltr">varchar(100)</span></td><td>
<select name="funcs[multi_edit][1][5096c410d87f661b9d8422246dcd2e89]" onchange="return verificationsAfterFieldChange('5096c410d87f661b9d8422246dcd2e89', '1','varchar(100)')" tabindex="3010" id="field_10_1"><option></option>
<option>ABS</option>
<option>ACOS</option>
<option>AES_DECRYPT</option>
<option>AES_ENCRYPT</option>
<option>ASCII</option>
<option>ASIN</option>
<option>ATAN</option>
<option>BIN</option>
<option>BIT_COUNT</option>
<option>BIT_LENGTH</option>
<option>CEILING</option>
<option>CHAR</option>
<option>CHAR_LENGTH</option>
<option>COMPRESS</option>
<option>CONNECTION_ID</option>
<option>COS</option>
<option>COT</option>
<option>CRC32</option>
<option>CURRENT_DATE</option>
<option>CURRENT_TIME</option>
<option>CURRENT_USER</option>
<option>DATABASE</option>
<option>DATE</option>
<option>DAYNAME</option>
<option>DAYOFMONTH</option>
<option>DAYOFWEEK</option>
<option>DAYOFYEAR</option>
<option>DEGREES</option>
<option>DES_DECRYPT</option>
<option>DES_ENCRYPT</option>
<option>ENCRYPT</option>
<option>EXP</option>
<option>FLOOR</option>
<option>FROM_DAYS</option>
<option>FROM_UNIXTIME</option>
<option>HEX</option>
<option>HOUR</option>
<option>INET6_ATON</option>
<option>INET6_NTOA</option>
<option>INET_ATON</option>
<option>INET_NTOA</option>
<option>LAST_DAY</option>
<option>LENGTH</option>
<option>LN</option>
<option>LOAD_FILE</option>
<option>LOG</option>
<option>LOG10</option>
<option>LOG2</option>
<option>LOWER</option>
<option>LTRIM</option>
<option>MD5</option>
<option>MICROSECOND</option>
<option>MINUTE</option>
<option>MONTH</option>
<option>MONTHNAME</option>
<option>NOW</option>
<option>OCT</option>
<option>OLD_PASSWORD</option>
<option>ORD</option>
<option>PASSWORD</option>
<option>PI</option>
<option>QUARTER</option>
<option>QUOTE</option>
<option>RADIANS</option>
<option>RAND</option>
<option>REVERSE</option>
<option>ROUND</option>
<option>RTRIM</option>
<option>SECOND</option>
<option>SEC_TO_TIME</option>
<option>SHA1</option>
<option>SIGN</option>
<option>SIN</option>
<option>SOUNDEX</option>
<option>SPACE</option>
<option>SQRT</option>
<option>SYSDATE</option>
<option>TAN</option>
<option>TIME</option>
<option>TIMESTAMP</option>
<option>TIME_TO_SEC</option>
<option>TO_DAYS</option>
<option>TO_SECONDS</option>
<option>TRIM</option>
<option>UNCOMPRESS</option>
<option>UNCOMPRESSED_LENGTH</option>
<option>UNHEX</option>
<option>UNIX_TIMESTAMP</option>
<option>UPPER</option>
<option>USER</option>
<option>UTC_DATE</option>
<option>UTC_TIME</option>
<option>UTC_TIMESTAMP</option>
<option>UUID</option>
<option>UUID_SHORT</option>
<option>VERSION</option>
<option>WEEK</option>
<option>WEEKDAY</option>
<option>WEEKOFYEAR</option>
<option>YEAR</option>
<option>YEARWEEK</option>
<option value="PHP_PASSWORD_HASH" title="The PHP function password_hash() with default options.">password_hash() PHP function</option>

</select>
</td>
<td></td>
<td data-type="varchar" data-decimals="100">
<span class="default_value hide"></span>


<textarea name="fields[multi_edit][1][5096c410d87f661b9d8422246dcd2e89]" class="char charField" data-maxlength="100" rows="7" cols="40" dir="ltr" id="field_10_3" onchange="return verificationsAfterFieldChange('5096c410d87f661b9d8422246dcd2e89', '1','varchar(100)')" tabindex="10" data-type="CHAR"></textarea>  </td></tr></tbody></table></div><br><div class="clearfloat"></div><fieldset id="actions_panel"><table cellpadding="5" cellspacing="0" class="pma-table tdblock w-100"><tbody><tr><td class="nowrap vmiddle"><select name="submit_type" class="control_at_footer" tabindex="11"><option value="insert">Insert as new row</option><option value="insertignore">Insert as new row and ignore errors</option><option value="showinsert">Show insert query</option></select>
</td><td class="vmiddle">&nbsp;&nbsp;&nbsp;<strong>and then</strong>&nbsp;&nbsp;&nbsp;</td><td class="nowrap vmiddle"><select name="after_insert" class="control_at_footer"><option value="back" selected="selected">Go back to previous page</option><option value="new_insert">Insert another new row</option></select></td></tr><tr><td><span class="pma_hint"><img src="themes/dot.gif" title="" alt="" class="icon ic_b_help"><span class="hide">Use TAB key to move from value to value, or CTRL+arrows to move anywhere.</span></span></td><td colspan="3" class="right vmiddle"><input type="button" class="btn btn-secondary preview_sql" value="Preview SQL" tabindex="16"><input type="reset" class="btn btn-secondary control_at_footer" value="Reset" tabindex="17"><input type="submit" class="btn btn-primary control_at_footer" value="Go" tabindex="18" id="buttonYes"></td></tr></tbody></table></fieldset></form><div id="gis_editor"></div><div id="popup_background"></div><br><form id="continueForm" method="post" action="index.php?route=/table/replace" name="continueForm">
    <input type="hidden" name="db" value="final"><input type="hidden" name="table" value="contents"><input type="hidden" name="token" value="35593a7b5d2d3f7a38664d356652283f">
    <input type="hidden" name="goto" value="index.php?route=/table/sql">
    <input type="hidden" name="err_url" value="index.php?route=/table/sql&amp;db=final&amp;table=contents">
    <input type="hidden" name="sql_query" value="">

    
        Continue insertion with         <input type="number" name="insert_rows" id="insert_rows" value="2" min="1">
     rows
</form>
</div>