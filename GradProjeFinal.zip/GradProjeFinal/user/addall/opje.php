<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="colorlib.com">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="vendor/nouislider/nouislider.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="main">

        <div class="container">
        <form method="POST" id="signup-form" class="signup-form" action="db_conn.php">            <div>

                    <h3>Course Objectives</h3>
                    <fieldset>
                        <h3>Course Objectives</h3>
                    <fieldset>
                        <h2>Course Objectives</h2>
                        <p class="desc">Please enter your Course Objectives</p>
                        <div class="fieldset-content">
                            <div class="form-group">
                             
                                <div class="form-find">
                                    <label>Course Objectives :</label>
                                    <br>
                                    
                                    <textarea name="objectives"  class="comment-area locale-data-placeholder" cols="100" rows="20" ></textarea>
                                </div>
                            </div>
                    </fieldset>
                </div>
                <button type="submit" href="/">Submit</button>
            </form>
            
        </div>

    </div>

  
</body>

</html>

