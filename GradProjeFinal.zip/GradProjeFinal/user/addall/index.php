<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="colorlib.com">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="vendor/nouislider/nouislider.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="main">
    
        <div class="container">
            <form method="POST" id="signup-form" class="signup-form" action="#">
                <div>
                    <i class="fas fa-pencil-alt"></i> 
                    
                    <fieldset>
                        
                    
                        <div class="fieldset-content">
                         
                            <div class="form-group">
                                
                               
                                    
                                    <div class="title">
                                      
                                      
                                    </div>
                                    <div class="info">
                                    <h1> <center><label>ADD COURSE</label></center>  </h1>
                                        <br>
                                        
                                    <label>Code</label>
                                      <input type="text" name="code">
                                      <label>Course Name</label>
                                      <input type="text" name="name" >
                                      <label>Hours</label>
                                      <input type="text" name="hours" >
                                      <label>Attend</label>
                                      <input type="text" name="attend" >
                                   
                                    </div>
                                   
                                   
                                  
                            </div>
                           
                         
                    </fieldset>

                    
                    <fieldset>
                    <center> <h2>Course Description</h2></center>
                       
                        <div class="fieldset-content">
                            <div class="form-group">
                             
                                <div class="form-find">
                                    <label>Course Description :</label>
                                    
                                    <textarea name="description"  class="comment-area locale-data-placeholder" cols="100" rows="20" ></textarea>
                                </div>
                            </div>
                            
                    </fieldset>

                 
                    <fieldset>
                    
                    <fieldset>
                    <center> <h2>Course Objectives</h2></center>
                      
                        <div class="fieldset-content">
                            <div class="form-group">
                             
                                <div class="form-find">
                                    <label>Course Objectives :</label>
                                    <br>
                                    
                                    <textarea name="objectives"  class="comment-area locale-data-placeholder" cols="100" rows="20" ></textarea>
                                </div>
                            </div>
                    </fieldset>
                  
                    <button type="submit" href="/">Submit</button>
                </div>
               
            </form>
            
        </div>

    </div>









    

   
</body>

</html>

<?PHP
require "db_conn.php";
$code=$_POST["code"];
$name=$_POST["name"];
$hours=$_POST["hours"];
$attend=$_POST["attend"];
$description=$_POST["description"];
$objectives=$_POST["objectives"];
    
    $sqi = "INSERT INTO course ( code, name, hours, attend)VALUES('$code','$name','$hours','$attend')";
    $sqi1 = "INSERT INTO description (  descr,courseid)VALUES('$description','$code')";
    $sqi2 = "INSERT INTO objectives (  obj,courseid)VALUES('$objectives','$code')";
    if ($conn->multi_query($sqi) == TRUE) {
        echo "DATA Insert";
        header('Location:http://localhost/final/user/home.php');
    } 
    if ($conn->multi_query($sqi1) == TRUE) {
        echo "DATA Insert1";
        header('Location:http://localhost/final/user/home.php');
    } 
    if ($conn->multi_query($sqi2) == TRUE) {
        echo "DATA Insert2";
        header('Location:http://localhost/final/user/home.php');
    } 
    $conn->close();
    







?>