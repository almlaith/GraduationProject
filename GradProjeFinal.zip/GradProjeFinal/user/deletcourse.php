<?php 
session_start();

if( isset($_SESSION['name'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $S= (int)$_GET['id'];
     
       require "db_conn.php";
       
       // delete comment fromd database
       if (isset($S)) {
           $id = $S;
           $sql = "DELETE FROM course WHERE code=" . $S;
           mysqli_query($conn, $sql);
           header("Location: home.php");
           exit();
       }
       
       
     ?>
   
</body>
</html>

<?php
}
else {
  header("Location: http://localhost/final/user/accss.php");

}
?>